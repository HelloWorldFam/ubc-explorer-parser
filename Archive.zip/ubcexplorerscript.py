import re
from ubcalend_txt import Scraper

class UBCExplorerScript:
    def __generate_json_array__(self, calendar_data):
        courses_array = []
        course = {}
        codes = []
        codeSet = set()
        deptJson = {}
        deptArray = []

        for line in calendar_data:
            if len(line) > 3 and line != 'newline':
                key, value = line.rstrip().split(': ', 1)
                course[key] = value.strip()
                
            elif line == 'newline':
                if course:
                    courses_array.append(course.copy())
                course.clear()
                continue

        for course in courses_array:
            if "cred" in course and len(course["cred"]) == 1:
                course["cred"] = int(course["cred"])
            else:
                course["cred"] = None
            
            if "dept" in course:
                codes.append(course["dept"])
        
        for dept in codes:
            codeSet.add(dept)

        array = []

        for code in codeSet:
            array.append(code)
        
        array.sort()

        for dept in array:
            deptJson["dept"] = dept
            deptArray.append(deptJson.copy())
            deptJson.clear()

        for course in courses_array:
            if "preq" in course:
                course["preq"] = re.findall(r'[A-Z]*\s\d{3}[A-Z]*', course["preq"])
            if "creq" in course:
                course["creq"] = re.findall(r'[A-Z]*\s\d{3}[A-Z]*', course["creq"])

        for course in courses_array:
            for course2 in courses_array:
                if "preq" in course2:
                    if "code" in course and "preq" in course2 and course["code"] in course2["preq"]:
                        if not "depn" in course:
                            course["depn"] = []
                        course["depn"].append(course2["code"])

        course_array = []

        for course in courses_array:
            code = course["code"].split(" ")
            course["link"] = "https://courses.students.ubc.ca/cs/courseschedule?pname=subjarea&tname=subj-course&dept=" + code[0] + "&course=" + code[1]
            course_array.append(course.copy())

        return course_array
        

    def main(self):
        scraper = Scraper()
        calendar_data = scraper.main()
        return self.__generate_json_array__(calendar_data)

